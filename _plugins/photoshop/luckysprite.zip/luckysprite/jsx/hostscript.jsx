/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global $, Folder*/
var doc, bigSprite;


function newDocFromMergedLayers(docName) {
    var desc = new ActionDescriptor();
    var ref = new ActionReference();
    ref.putEnumerated(charIDToTypeID('Dcmn'), charIDToTypeID('Ordn'), charIDToTypeID('Frst'));
    desc.putReference(charIDToTypeID('null'), ref);
    desc.putString(charIDToTypeID('Nm  '), docName);
    desc.putBoolean(charIDToTypeID('Mrgd'), true);
    executeAction(charIDToTypeID('Dplc'), desc, DialogModes.NO);
};

function SavePNG(saveFile) {

    var pngOpts = new ExportOptionsSaveForWeb;
    pngOpts.format = SaveDocumentType.PNG
    pngOpts.PNG8 = false;
    pngOpts.transparency = true;
    pngOpts.interlaced = false;
    pngOpts.quality = 100;
    activeDocument.exportDocument(new File(doc.path + "/" + saveFile), ExportType.SAVEFORWEB, pngOpts);

}
function SavePNGToFolder(saveFile,ExportFodler) {
  var filePath = app.activeDocument.path;
  var exportFolder = filePath + "/"+ExportFodler+"/";
  var f = new Folder(exportFolder);
  if ( ! f.exists ) {
  	f.create()
  }
  var aFile = File(exportFolder+saveFile);
    var pngOpts = new ExportOptionsSaveForWeb;
    pngOpts.format = SaveDocumentType.PNG
    pngOpts.PNG8 = false;
    pngOpts.transparency = true;
    pngOpts.interlaced = false;
    pngOpts.quality = 100;
    activeDocument.exportDocument(aFile, ExportType.SAVEFORWEB, pngOpts);

}


function getInfo() {
    return (app.activeDocument.activeLayer.bounds);

}

function DoubleResSS(direction, mode) {
    doc = app.activeDocument;
    var origHeight = parseInt(doc.height);

    doc.resizeImage(null, UnitValue(origHeight * 2, "px"), null, ResampleMethod.BICUBIC);

    makeSpriteSheet(direction, 1);

    app.activeDocument = doc;
    doc.resizeImage(null, UnitValue(origHeight, "px"), null, ResampleMethod.BICUBIC);
    app.activeDocument = bigSprite;
}

function makeSpriteSheet(direction, mode) {

    doc = app.activeDocument;
    var comps = doc.layerComps;
    var bgComp = -1;
    for (var i = 0; i < comps.length; i++) {

        if (comps[i].name == "bg") {
            bgComp = i;
        }
    }

    //needed for copy paste
    var startRulerUnits = app.preferences.rulerUnits;
    app.preferences.rulerUnits = Units.PIXELS; // tell ps to work with pixels
    app.preferences.rulerUnits = startRulerUnits;
    //selectArea(20,10,50,50);

    //pick up the comps and label them
    var comps = doc.layerComps;

    //get the original history level
    var savedState = app.activeDocument.activeHistoryState;

    //label the sprite, take off the extension, add with and height
    if (mode == 0) {
        var spriteName = doc.name.split(".")[0] + "_spritesheet-" + doc.width.value + "x" + doc.height.value;
    } else {
        var spriteName = doc.name.split(".")[0] + "_spritesheet-" + doc.width.value / 2 + "x" + doc.height.value / 2 + "-2x";
    }

    //make a spritesheet
    bigSprite = app.documents.add(doc.width, doc.height, 72, spriteName, NewDocumentMode.RGB, DocumentFill.TRANSPARENT);

    var tempFiles = [];

    for (var i = 0; i < comps.length; i++) {
        if(i!=bgComp){
        app.activeDocument = doc;
        comps[i].apply();

        newDocFromMergedLayers("temp");
        var mergedBounds = app.activeDocument.activeLayer.bounds;
        app.activeDocument.trim(TrimType.TRANSPARENT);

        app.activeDocument.selection.selectAll();
        app.activeDocument.selection.copy();
        app.activeDocument = bigSprite;
        app.activeDocument.paste();

        //change based off direction

        mergedBounds[1] += doc.height.value * i;
        app.activeDocument.guides.add(Direction.HORIZONTAL, doc.height.value * i);


        //fix the offset from pasting
        var pasteXY = {
            x: app.activeDocument.activeLayer.bounds[0].value,
            y: app.activeDocument.activeLayer.bounds[1].value
        };
        app.activeDocument.activeLayer.translate(-pasteXY.x, -pasteXY.y);
       if(bgComp!=-1 && i>bgComp){
           mergedBounds[1]-=doc.height.value;
        }
        //assign original(calculated) values
        app.activeDocument.activeLayer.translate(mergedBounds[0], mergedBounds[1]);

        //close the temp document created
        app.documents[app.documents.length - 1].close(SaveOptions.DONOTSAVECHANGES);

    }

    }

    app.activeDocument.guides.add(Direction.HORIZONTAL, doc.height.value * comps.length);

    //if theres a composition called bg adjust the height so its placed last with a gap


    // alert(app.activeDocument.layers[2])
    // var bgSelect = {startY:1, endY:1}
    // var shapeRef= [ [0,0], [0,100], [100,100], [100,0] ];
    //   app.activeDocument.selection.select(shapeRef);
    if(bgComp!=-1){
      app.activeDocument.resizeCanvas(doc.width, doc.height * (comps.length+1), AnchorPosition.TOPLEFT);
      app.activeDocument = doc;
      comps[bgComp].apply();
      newDocFromMergedLayers("bg");

      var mergedBounds = app.activeDocument.activeLayer.bounds;
      app.activeDocument.trim(TrimType.TRANSPARENT);

      app.activeDocument.selection.selectAll();
      app.activeDocument.selection.copy();
      app.activeDocument = bigSprite;
      app.activeDocument.paste();


      var pasteXY = {
        x: app.activeDocument.activeLayer.bounds[0].value,
        y: app.activeDocument.activeLayer.bounds[1].value
      };
      app.activeDocument.activeLayer.translate(-pasteXY.x, -pasteXY.y);

      //assign original(calculated) values
      app.activeDocument.activeLayer.translate(0, app.activeDocument.height - doc.height);

      app.documents[app.documents.length - 1].close(SaveOptions.DONOTSAVECHANGES);
      app.activeDocument.guides.add(Direction.HORIZONTAL, app.activeDocument.height - doc.height);
    }
    else{
      //alert(bgComp);
      //otherwise behave normal, no bg offset
      app.activeDocument.resizeCanvas(doc.width, doc.height * comps.length, AnchorPosition.TOPLEFT);
   }

    activeDocument.mergeVisibleLayers();
    app.activeDocument.activeLayer.name = "spritesheet";

    SavePNG(spriteName + ".png");
}

function LayerCompstoFiles() {
  var doc = app.activeDocument ;
  var ExportFolder = doc.name.replace(".psd","");

  //pick up the comps and label them
  var comps = doc.layerComps;

  for (var i = 0; i < comps.length; i++) {
  var location =  comps[i].name+".png";
     comps[i].apply();
       SavePNGToFolder(location, ExportFolder)
     }
     alert("DONE!");

}


function checkCompositions(direction, mode) {
    if (app.activeDocument.layerComps.length > 0) {
        makeSpriteSheet(direction, mode);
    } else {
        alert('No layer compositions in this document');

    }

}
