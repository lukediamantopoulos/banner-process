/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global $, window, location, CSInterface, SystemPath, themeManager*/
direction = 'ud';

(function() {
    'use strict';

    var csInterface = new CSInterface();

    function init() {

        themeManager.init();

        $("#btn_test").click(function() {
            //ignoreLayers

            var mode = 0;
            var functionCall = "checkCompositions('" + direction + "','" + mode + "');"
            csInterface.evalScript(functionCall);
        });''
        $("#btn_LayerComps").click(function() {

            var functionCall = "LayerCompstoFiles();"

            csInterface.evalScript(functionCall);
        });
        $("#checkV").click(function(e) {
            direction = 'ud';
        });
        $("#checkH").click(function(e) {
            direction = 'lr';


        });
    };

    init();

}());
